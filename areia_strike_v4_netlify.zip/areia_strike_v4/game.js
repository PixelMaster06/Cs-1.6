import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";
const scene=new THREE.Scene();scene.background=new THREE.Color(0x9aabb0);scene.fog=new THREE.Fog(0x9aabb0,42,115);
const camera=new THREE.PerspectiveCamera(75,innerWidth/innerHeight,.08,180);
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;document.body.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xffe9c8,0x5c4936,1.8));const sun=new THREE.DirectionalLight(0xffe0b2,2.4);sun.position.set(-25,45,20);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);scene.add(sun);
const mats={sand:new THREE.MeshStandardMaterial({color:0xc7aa78,roughness:1}),stone:new THREE.MeshStandardMaterial({color:0xb49a70,roughness:1}),stone2:new THREE.MeshStandardMaterial({color:0x927c5b,roughness:1}),wood:new THREE.MeshStandardMaterial({color:0x725638,roughness:1}),metal:new THREE.MeshStandardMaterial({color:0x303438,metalness:.65,roughness:.45})};
function proceduralTexture(base,accent){const c=document.createElement("canvas");c.width=c.height=256;const x=c.getContext("2d");x.fillStyle=base;x.fillRect(0,0,256,256);for(let i=0;i<1200;i++){x.fillStyle=`rgba(45,35,22,${Math.random()*.12})`;x.fillRect(Math.random()*256,Math.random()*256,Math.random()*7+1,Math.random()*4+1)}for(let y=0;y<256;y+=32){x.strokeStyle=accent;x.globalAlpha=.13;x.strokeRect(0,y,256,32)}const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(2,2);return t}
mats.stone.map=proceduralTexture("#b79d73","#6e5a3e");mats.stone.needsUpdate=true;
const colliders=[];
function block(x,y,z,w,h,d,material=mats.stone,collide=true){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;scene.add(o);if(collide)colliders.push({minX:x-w/2,maxX:x+w/2,minZ:z-d/2,maxZ:z+d/2});return o}
block(0,-.3,0,110,.6,110,mats.sand,false);
// Architectural Dust-inspired original arena: lanes, raised ramp, mid, tunnels, A/B courtyards.
const walls=[
[-24,2,-14,20,4,5],[-24,2,14,20,4,5],[24,2,-14,20,4,5],[24,2,14,20,4,5],
[-8,2,-31,5,4,16],[8,2,-31,5,4,16],[-8,2,31,5,4,16],[8,2,31,5,4,16],
[-37,2,0,5,4,25],[37,2,0,5,4,25],[-15,2,0,8,4,5],[15,2,0,8,4,5],
[-39,2,-25,13,4,5],[39,2,25,13,4,5],[-39,2,25,13,4,5],[39,2,-25,13,4,5],
[-28,2,-34,5,4,10],[28,2,34,5,4,10],[-28,2,34,5,4,10],[28,2,-34,5,4,10]
];walls.forEach(a=>block(...a));
for(const [x,z] of [[-18,-8],[-18,8],[18,-8],[18,8],[-31,-8],[31,8],[0,-20],[0,20],[-40,0],[40,0]])block(x,.85,z,2.6,1.7,2.6,mats.wood);
for(let i=0;i<5;i++){block(-4+i*2,.35,-8,1.8,.7,1.8,mats.wood);block(4-i*2,.35,8,1.8,.7,1.8,mats.wood)}
// ramps / raised platforms
block(-27,.45,0,8,.9,10,mats.stone2);block(27,.45,0,8,.9,10,mats.stone2);
function sign(txt,x,z){const c=document.createElement("canvas");c.width=256;c.height=96;const g=c.getContext("2d");g.fillStyle="#21190fe0";g.fillRect(0,0,256,96);g.fillStyle="#f4d39a";g.font="bold 64px Arial";g.textAlign="center";g.fillText(txt,128,70);const s=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c)}));s.position.set(x,4,z);s.scale.set(5,1.8,1);scene.add(s)}sign("B",29,-29);sign("A",-29,29);sign("MID",0,0);
const player=new THREE.Group();camera.add(player);scene.add(camera);
const gun=new THREE.Group();player.add(gun);const gunmat=new THREE.MeshStandardMaterial({color:0x202428,metalness:.7,roughness:.4}),wood=new THREE.MeshStandardMaterial({color:0x68482d});
function gunPart(w,h,d,x,y,z,m){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);gun.add(o);return o}
gunPart(.17,.16,.58,.3,-.25,-.48,gunmat);gunPart(.12,.13,.3,.3,-.34,-.42,wood);gunPart(.045,.045,.48,.3,-.21,-.88,gunmat);gunPart(.08,.12,.13,.3,-.12,-.45,gunmat);
const muzzle=new THREE.PointLight(0xffc16a,0,4);muzzle.position.set(.3,-.2,-1);gun.add(muzzle);
let yaw=0,pitch=0,locked=false,hp=100,armor=0,weapon="AK-47",ammo=30,reserve=90,reloading=false,lastShot=0,shots=0,lastSprayAt=0,move=0,vertical=0,ground=true;
const cfg={"AK-47":{mag:30,rate:105,damage:34,spread:.012,reload:2100},"M4A1":{mag:30,rate:90,damage:29,spread:.009,reload:1900},"AWP":{mag:10,rate:1250,damage:100,spread:.002,reload:2700}};
let socket,myId=null,team="CT",others=new Map(),remoteMeshes=new Map(),bomb=false,roundNo=1;
let money=800, grenades={HE:1,FLASH:2,SMOKE:1}, grenadeType="HE", buyOpen=false, roundStart=performance.now();
const grenadeObjects=[];
const $=id=>document.getElementById(id),say=t=>{$("feed").innerHTML=t+"<br>"+$("feed").innerHTML};
function connect(){const wsUrl=window.GAME_SERVER_URL || `${location.protocol==="https:"?"wss":"ws"}://${location.hostname}:${location.port||8080}`;
socket=new WebSocket(wsUrl);socket.onopen=()=>$("net").textContent="LAN ONLINE";socket.onclose=()=>$("net").textContent="SEM CONEXÃO";socket.onmessage=e=>{const m=JSON.parse(e.data);
if(m.type==="welcome"){myId=m.you.id;team=m.you.team;camera.position.set(m.you.x,1.7,m.you.z);m.players.forEach(p=>{if(p.id!==myId)addRemote(p)});say("Você entrou como "+team)}
if(m.type==="join")addRemote(m.player);if(m.type==="leave"){const o=remoteMeshes.get(m.id);if(o)scene.remove(o);remoteMeshes.delete(m.id)}
if(m.type==="state"&&m.player.id!==myId){const o=remoteMeshes.get(m.player.id);if(o){o.userData.target.set(m.player.x,m.player.crouch?.65:.95,m.player.z);o.rotation.y=m.player.yaw}}
if(m.type==="chat")say(m.name+": "+m.text);if(m.type==="kill"){$("killfeed").innerHTML=m.killer+" ✦ "+m.victim+"<br>"+$("killfeed").innerHTML;if(m.killerId===myId){money=m.money;hud()}}
if(m.type==="roundresult")say("ROUND: "+m.winner+" venceu");
if(m.type==="money"&&m.id===myId){money=m.money;hud()}
if(m.type==="buyresult"&&m.id===myId&&m.ok){if(m.item==="AK-47"||m.item==="M4A1"||m.item==="AWP"){weapon=m.item;ammo=cfg[weapon].mag;reserve=weapon==="AWP"?30:90}if(m.item==="Colete")armor=100;if(["HE","FLASH","SMOKE"].includes(m.item))grenades[m.item]++;hud()}
if(m.type==="buyresult"&&m.id===myId)say(m.ok?"Compra realizada": "Compra recusada: "+m.reason);
if(m.type==="health"&&m.id===myId){hp=m.hp;armor=m.armor||0;hud()}
if(m.type==="hitconfirm"&&m.shooter===myId)say(m.head?"HEADSHOT!":"ACERTO!");if(m.type==="bomb"){bomb=m.action==="plant";say(m.action==="explode"?"BOMBA EXPLODIU!":bomb?"C4 PLANTADA":"C4 DESARMADA")}
if(m.type==="clock"){const r=m.round;$("round").textContent="ROUND "+r.number;$("clock").textContent=Math.floor(r.time/60)+":"+String(r.time%60).padStart(2,"0")}
if(m.type==="round"&&m.round.phase==="END")say("FIM DO ROUND");
if(m.type==="roundreset"){hp=100;armor=0;ammo=cfg[weapon].mag;reserve=weapon==="AWP"?30:90;hud();}
if(m.type==="shot")remoteShot(m);
}}
function addRemote(p){if(remoteMeshes.has(p.id))return;const g=new THREE.Group(),body=new THREE.Mesh(new THREE.CapsuleGeometry(.35,.75,4,8),new THREE.MeshStandardMaterial({color:p.team==="CT"?0x405f80:0x985537}));body.position.y=.85;body.castShadow=true;g.add(body);g.userData.target=new THREE.Vector3(p.x,.95,p.z);g.position.copy(g.userData.target);scene.add(g);remoteMeshes.set(p.id,g)}
function remoteShot(m){const a=new THREE.Vector3(...m.origin),d=new THREE.Vector3(...m.dir);const ray=new THREE.Raycaster(a,d,0,80);const hits=ray.intersectObjects([...remoteMeshes.values()],true);if(hits.length){const id=[...remoteMeshes.entries()].find(([k,g])=>g===hits[0].object.parent||g===hits[0].object.parent?.parent)?.[0];if(id&&socket?.readyState===1)socket.send(JSON.stringify({type:"hit",target:id,damage:cfg[m.weapon]?.damage||25}))}}
connect();
const keys={};addEventListener("keydown",e=>{keys[e.code]=true;if(e.code==="KeyR")reload();if(e.code==="Digit1")equip("AK-47");if(e.code==="Digit2")equip("M4A1");if(e.code==="Digit3")equip("AWP");if(e.code==="KeyE")bombAction();
if(e.code==="KeyB")toggleBuy();
if(e.code==="KeyG")throwGrenade();
if(e.code==="KeyF")grenadeType=grenadeType==="HE"?"FLASH":grenadeType==="FLASH"?"SMOKE":"HE";
if(e.code==="KeyT"&&!e.repeat){$("chatbox").style.display="block";$("chatinput").focus();document.exitPointerLock()}if(e.code==="Escape")$("chatbox").style.display="none"});
addEventListener("keyup",e=>keys[e.code]=false);
$("chatinput").addEventListener("keydown",e=>{if(e.key==="Enter"){const text=e.target.value.trim();if(text&&socket?.readyState===1)socket.send(JSON.stringify({type:"chat",text}));e.target.value="";$("chatbox").style.display="none";renderer.domElement.requestPointerLock()}});
renderer.domElement.addEventListener("click",()=>{if(!locked)renderer.domElement.requestPointerLock();else shoot()});document.addEventListener("pointerlockchange",()=>{locked=document.pointerLockElement===renderer.domElement;$("centerMsg").style.display=locked?"none":"block"});
document.addEventListener("mousemove",e=>{if(!locked)return;yaw-=e.movementX*.0022;pitch-=e.movementY*.0022;pitch=Math.max(-1.5,Math.min(1.5,pitch));camera.rotation.set(pitch,yaw,0,"YXZ")});
function equip(w){weapon=w;ammo=cfg[w].mag;reserve=w==="AWP"?30:90;hud()}
function hud(){$("hp").textContent=hp;$("armor").textContent=armor;$("cash").textContent="$"+money;$("weapon").textContent=weapon;$("ammo").textContent=ammo+" / "+reserve}
function reload(){if(reloading||ammo===cfg[weapon].mag||reserve<=0)return;reloading=true;gun.rotation.x=-.18;setTimeout(()=>{const n=Math.min(cfg[weapon].mag-ammo,reserve);ammo+=n;reserve-=n;reloading=false;gun.rotation.x=0;hud()},cfg[weapon].reload)}
function collides(x,z){const r=.38;return colliders.some(c=>x+r>c.minX&&x-r<c.maxX&&z+r>c.minZ&&z-r<c.maxZ)}
function weaponSound(){try{const ctx=weaponSound.ctx||(weaponSound.ctx=new AudioContext()),o=ctx.createOscillator(),gain=ctx.createGain();o.type="sawtooth";o.frequency.setValueAtTime(weapon==="AWP"?95:weapon==="M4A1"?145:120,ctx.currentTime);o.frequency.exponentialRampToValueAtTime(35,ctx.currentTime+.09);gain.gain.setValueAtTime(.07,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+.11);o.connect(gain);gain.connect(ctx.destination);o.start();o.stop(ctx.currentTime+.12)}catch(e){}}
function shoot(){const c=cfg[weapon],now=performance.now();if(now-lastShot<c.rate||ammo<=0||reloading)return;if(now-lastSprayAt>420)shots=0;lastSprayAt=now;lastShot=now;ammo--;shots++;weaponSound();const kick=weapon==="AWP"?.045:.012+Math.min(shots,7)*.0018;pitch=Math.min(1.5,pitch+kick);camera.rotation.x=pitch;
const pattern=sprayPatterns[weapon][Math.min(shots,sprayPatterns[weapon].length-1)]||[0,0];
const spread=c.spread*(1+(move?1.8:0)+(keys.ControlLeft?-.25:0));
const dir=new THREE.Vector3(pattern[0]*spread+(Math.random()-.5)*spread*.35,
-pattern[1]*spread+(Math.random()-.5)*spread*.35,-1).normalize().applyQuaternion(camera.quaternion);const origin=camera.position.clone();
if(socket?.readyState===1)socket.send(JSON.stringify({type:"fire",origin:origin.toArray(),dir:dir.toArray(),weapon,shotIndex:shots,clientTime:Date.now()}));
muzzle.intensity=3;setTimeout(()=>muzzle.intensity=0,45);gun.position.z=.09;setTimeout(()=>gun.position.z=0,60);shots=shots%10;hud();crosshair()}
function crosshair(){const spread=5+move*3+Math.min(shots,7)*1.3;$("crosshair").style.transform=`translate(-50%,-50%) scale(${spread/10})`}
function toggleBuy(){buyOpen=!buyOpen;let panel=document.getElementById("buyPanel");if(panel)panel.style.display=buyOpen?"block":"none";if(buyOpen)document.exitPointerLock();else renderer.domElement.requestPointerLock()}
function buy(item,cost){if(socket?.readyState===1){socket.send(JSON.stringify({type:"buy",item}));return}if(money<cost){say("Dinheiro insuficiente");return}money-=cost;
 if(item==="AK-47"||item==="M4A1"||item==="AWP"){weapon=item;ammo=cfg[item].mag;reserve=item==="AWP"?30:90}
 if(item==="Colete"){armor=100}
 if(item==="HE")grenades.HE++;if(item==="FLASH")grenades.FLASH++;if(item==="SMOKE")grenades.SMOKE++;
 hud();say(item+" comprado");}
function throwGrenade(){if(!grenades[grenadeType]){say("Sem "+grenadeType);return}grenades[grenadeType]--;
 const dir=new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion),g=new THREE.Mesh(new THREE.SphereGeometry(.13,12,8),new THREE.MeshStandardMaterial({color:grenadeType==="HE"?0x4a5545:grenadeType==="FLASH"?0xd8d8b2:0x343b40,metalness:.3}));
 g.position.copy(camera.position).add(dir.clone().multiplyScalar(.8));scene.add(g);
 grenadeObjects.push({mesh:g,vel:dir.multiplyScalar(12).add(new THREE.Vector3(0,4,0)),life:2.4,type:grenadeType});
 say(grenadeType+" lançada");}
function grenadeEffect(g){if(g.type==="HE"){const blast=new THREE.Mesh(new THREE.SphereGeometry(3,16,12),new THREE.MeshBasicMaterial({color:0xff8a32,transparent:true,opacity:.45}));blast.position.copy(g.mesh.position);scene.add(blast);setTimeout(()=>scene.remove(blast),350);say("Explosão HE!")}
 if(g.type==="FLASH"){const overlay=document.createElement("div");overlay.style.cssText="position:fixed;inset:0;background:white;z-index:9;pointer-events:none";document.body.appendChild(overlay);setTimeout(()=>overlay.remove(),900);say("Flashbang!")}
 if(g.type==="SMOKE"){const cloud=new THREE.Mesh(new THREE.SphereGeometry(3.4,16,12),new THREE.MeshBasicMaterial({color:0x999999,transparent:true,opacity:.28,depthWrite:false}));cloud.position.copy(g.mesh.position);scene.add(cloud);setTimeout(()=>scene.remove(cloud),9000);say("Fumaça lançada")}}
function bombAction(){const p=camera.position;if(Math.abs(p.x)>22&&Math.abs(p.z)>22&&socket?.readyState===1){socket.send(JSON.stringify({type:"bomb",action:bomb?"defuse":"plant",site:p.x<0?"A":"B"}))}}
let prev=performance.now(),send=0;
function animate(t){requestAnimationFrame(animate);const dt=Math.min((t-prev)/1000,.04);prev=t;
if(locked){const crouch=keys.ControlLeft||keys.ControlRight,sprint=keys.ShiftLeft&&!crouch,speed=(crouch?2.1:sprint?6.8:4.7)*dt;const f=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw)),r=new THREE.Vector3(Math.cos(yaw),0,-Math.sin(yaw));let dx=0,dz=0;if(keys.KeyW){dx+=f.x;dz+=f.z}if(keys.KeyS){dx-=f.x;dz-=f.z}if(keys.KeyD){dx+=r.x;dz+=r.z}if(keys.KeyA){dx-=r.x;dz-=r.z}move=Math.min(1,Math.hypot(dx,dz));if(move){const l=Math.hypot(dx,dz);dx=dx/l*speed;dz=dz/l*speed;if(!collides(camera.position.x+dx,camera.position.z))camera.position.x+=dx;if(!collides(camera.position.x,camera.position.z+dz))camera.position.z+=dz}
if(keys.Space&&ground){vertical=5;ground=false}vertical-=15*dt;camera.position.y+=vertical*dt;const floor=crouch?1.05:1.7;if(camera.position.y<=floor){camera.position.y=floor;vertical=0;ground=true}if(!crouch&&camera.position.y>1.7)camera.position.y=1.7;
camera.position.x=THREE.MathUtils.clamp(camera.position.x,-49,49);camera.position.z=THREE.MathUtils.clamp(camera.position.z,-49,49);gun.position.y=-Math.sin(t*.012)*move*.012;crosshair();
if(socket?.readyState===1&&t-send>65){send=t;socket.send(JSON.stringify({type:"state",x:camera.position.x,z:camera.position.z,yaw,hp,weapon,crouch,reloading}))}}
for(const g of remoteMeshes.values())g.position.lerp(g.userData.target,.22);
for(let i=grenadeObjects.length-1;i>=0;i--){const g=grenadeObjects[i];g.life-=dt;g.vel.y-=9.8*dt;g.mesh.position.addScaledVector(g.vel,dt);if(g.mesh.position.y<.18){g.mesh.position.y=.18;g.vel.y*=-.38;g.vel.x*=.72;g.vel.z*=.72}if(g.life<=0){grenadeEffect(g);scene.remove(g.mesh);grenadeObjects.splice(i,1)}}
renderer.render(scene,camera)}
hud();
const buyPanel=document.createElement("div");buyPanel.id="buyPanel";buyPanel.style.cssText="display:none;position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:10;pointer-events:auto;background:#101820f2;border:2px solid #c9a66b;padding:18px;min-width:300px;color:white;font:14px Arial";
buyPanel.innerHTML='<h2>ARSENAL · B</h2><p>AK-47 — $2700 <button data-item="AK-47" data-cost="2700">Comprar</button></p><p>M4A1 — $3100 <button data-item="M4A1" data-cost="3100">Comprar</button></p><p>AWP — $4750 <button data-item="AWP" data-cost="4750">Comprar</button></p><p>Colete — $650 <button data-item="Colete" data-cost="650">Comprar</button></p><p>HE — $300 <button data-item="HE" data-cost="300">Comprar</button></p><p>Flash — $200 <button data-item="FLASH" data-cost="200">Comprar</button></p><p>Smoke — $300 <button data-item="SMOKE" data-cost="300">Comprar</button></p><button id="closeBuy">Fechar (B)</button>';
document.body.appendChild(buyPanel);buyPanel.addEventListener("click",e=>{if(e.target.dataset.item)buy(e.target.dataset.item,Number(e.target.dataset.cost));if(e.target.id==="closeBuy")toggleBuy()});
animate(performance.now());addEventListener("resize",()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
