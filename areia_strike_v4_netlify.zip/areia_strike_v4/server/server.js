const http=require("http"),fs=require("fs"),path=require("path"),WebSocket=require("ws");
const root=__dirname,server=http.createServer((req,res)=>{let p=decodeURIComponent((req.url||"/").split("?")[0]);if(p==="/")p="/index.html";const f=path.join(root,p);if(!f.startsWith(root)){res.writeHead(403);return res.end()}fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end("404")}res.writeHead(200,{"Content-Type":({".html":"text/html",".js":"text/javascript",".css":"text/css"}[path.extname(f)]||"application/octet-stream")});res.end(d)})});
const wss=new WebSocket.Server({server}),players=new Map();let seq=1;
const round={number:1,time:105,phase:"LIVE",bomb:null,ctScore:0,tScore:0};
const prices={"AK-47":2700,"M4A1":3100,"AWP":4750,"Colete":650,"HE":300,"FLASH":200,"SMOKE":300};
const damage={"AK-47":34,"M4A1":29,"AWP":100};
const clamp=(n,a,b)=>Math.max(a,Math.min(b,Number(n)||0));
function send(ws,o){if(ws&&ws.readyState===1)ws.send(JSON.stringify(o))}
function broadcast(o,except){for(const [id,v] of players)if(id!==except)send(v.ws,o)}
function finish(winner){if(round.phase!=="LIVE")return;round.phase="END";round.time=7;if(winner==="CT")round.ctScore++;if(winner==="T")round.tScore++;broadcast({type:"roundresult",winner,round});}
function reset(){round.number++;round.phase="LIVE";round.time=105;round.bomb=null;for(const {player:p} of players.values()){p.hp=100;p.armor=0;p.money=Math.min(16000,p.money+3250);p.x=p.team==="CT"?-34:34;p.z=0;send(players.get(p.id)?.ws,{type:"roundreset",round});send(players.get(p.id)?.ws,{type:"money",id:p.id,money:p.money})}broadcast({type:"round",round});}
function raySphere(origin,dir,center,r){const oc={x:origin[0]-center.x,y:origin[1]-center.y,z:origin[2]-center.z};const b=oc.x*dir[0]+oc.y*dir[1]+oc.z*dir[2];const c=oc.x*oc.x+oc.y*oc.y+oc.z*oc.z-r*r;const h=b*b-c;if(h<0)return null;const t=-b-Math.sqrt(h);return t>0?t:null}
function fire(shooter,m){if(round.phase!=="LIVE"||shooter.hp<=0)return;const d=m.dir,o=m.origin;if(!Array.isArray(d)||!Array.isArray(o)||d.length!==3||o.length!==3)return;
const len=Math.hypot(...d);if(len<.8||len>1.2)return;const dir=d.map(v=>v/len);let best=null,bestT=80;
for(const {player:p} of players.values()){if(p.id===shooter.id||p.team===shooter.team||p.hp<=0)continue;const t=raySphere(o,dir,{x:p.x,y:.95,z:p.z},.78);if(t!==null&&t<bestT){best=p;bestT=t}}
if(best){const hitY=o[1]+dir[1]*bestT;const head=hitY>1.42;let dmg=damage[m.weapon]||25;if(head)dmg*=2;if(m.weapon==="AWP")dmg=100;
let absorbed=0;if(best.armor>0){absorbed=Math.min(best.armor,Math.round(dmg*.45));best.armor-=absorbed;dmg-=absorbed}best.hp=Math.max(0,best.hp-dmg);send(players.get(best.id)?.ws,{type:"health",id:best.id,hp:best.hp,armor:best.armor});send(players.get(shooter.id)?.ws,{type:"hitconfirm",shooter:shooter.id,head});
if(best.hp===0){shooter.kills++;best.deaths++;shooter.money=Math.min(16000,shooter.money+300);broadcast({type:"kill",killer:shooter.name,victim:best.name,killerId:shooter.id,money:shooter.money});send(players.get(shooter.id)?.ws,{type:"money",id:shooter.id,money:shooter.money});const alive=[...players.values()].map(x=>x.player).filter(p=>p.team===best.team&&p.hp>0).length;if(alive===0)finish(shooter.team)}
}
broadcast({type:"shotfx",id:shooter.id,origin:o,dir:d,weapon:m.weapon},shooter.id);
}
wss.on("connection",ws=>{const id=String(seq++),ct=[...players.values()].filter(x=>x.player.team==="CT").length,t=[...players.values()].filter(x=>x.player.team==="T").length,team=ct<=t?"CT":"T";
const player={id,name:"Player "+id,team,x:team==="CT"?-34:34,z:0,yaw:team==="CT"?Math.PI:0,hp:100,armor:0,weapon:"AK-47",kills:0,deaths:0,money:800,he:0,flash:0,smoke:0,lastFire:0};
players.set(id,{ws,player});send(ws,{type:"welcome",you:player,players:[...players.values()].map(x=>x.player),round});broadcast({type:"join",player},id);
ws.on("message",raw=>{let m;try{m=JSON.parse(raw)}catch{return}const p=players.get(id)?.player;if(!p)return;
if(m.type==="state"){p.x=clamp(m.x,-48,48);p.z=clamp(m.z,-48,48);p.yaw=clamp(m.yaw,-1000,1000);p.hp=Math.max(0,Math.min(100,p.hp));p.weapon=Object.hasOwn(damage,m.weapon)?m.weapon:p.weapon;p.crouch=!!m.crouch;p.reloading=!!m.reloading;broadcast({type:"state",player:p},id)}
if(m.type==="fire"){const now=Date.now(),rate=m.weapon==="AWP"?1200:m.weapon==="M4A1"?90:105;if(now-p.lastFire<rate)return;p.lastFire=now;fire(p,m)}
if(m.type==="buy"){const cost=prices[m.item];if(!cost||p.money<cost){send(ws,{type:"buyresult",id,ok:false,reason:"saldo insuficiente"});return}p.money-=cost;if(m.item==="Colete")p.armor=100;else if(m.item==="HE")p.he++;else if(m.item==="FLASH")p.flash++;else if(m.item==="SMOKE")p.smoke++;else p.weapon=m.item;send(ws,{type:"buyresult",id,ok:true,item:m.item});send(ws,{type:"money",id,money:p.money});}
if(m.type==="chat")broadcast({type:"chat",id,name:p.name,text:String(m.text||"").slice(0,120)});
if(m.type==="bomb"){if(m.action==="plant"&&p.team==="T"&&!round.bomb){round.bomb={site:m.site,seconds:40,by:id};broadcast({type:"bomb",action:"plant",site:m.site})}else if(m.action==="defuse"&&p.team==="CT"&&round.bomb){round.bomb=null;finish("CT");broadcast({type:"bomb",action:"defuse"})}}
});
ws.on("close",()=>{players.delete(id);broadcast({type:"leave",id})});
});
setInterval(()=>{if(round.phase==="LIVE"){round.time--;if(round.bomb){round.bomb.seconds--;if(round.bomb.seconds<=0){round.bomb=null;broadcast({type:"bomb",action:"explode"});finish("T")}}if(round.time<=0)finish("CT")}else{round.time--;if(round.time<=0)reset()}broadcast({type:"clock",round})},1000);
server.listen(process.env.PORT||8080,"0.0.0.0",()=>console.log("Areia Strike realtime server on "+(process.env.PORT||8080)));