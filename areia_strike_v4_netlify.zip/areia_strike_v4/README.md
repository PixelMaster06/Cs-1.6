# Areia Strike v4 — Netlify + Render

## Publicação
O Netlify hospeda o frontend estático; o Render hospeda o servidor WebSocket.
1. Suba a pasta inteira para um repositório GitHub.
2. No Render, crie um Web Service com Root Directory `server`, Build Command `npm install`, Start Command `npm start`. O arquivo `render.yaml` também pode ser usado como Blueprint.
3. Copie a URL HTTPS do serviço Render e converta para `wss://...`.
4. Edite `config.js`: `window.GAME_SERVER_URL = "wss://SEU-SERVIDOR.onrender.com";`
5. No Netlify, importe o repositório. Build command vazio; Publish directory `.`.
6. Abra o domínio Netlify em duas ou mais abas/dispositivos para testar.

## Controles
WASD mover · Shift correr · Ctrl agachar · Espaço pular · mouse mirar · clique atirar · R recarregar · 1/2/3 armas · B loja · E C4 · F alternar HE/FLASH/SMOKE · G lançar · T chat.

## Melhorias desta versão
- Servidor WebSocket separado para Render e frontend estático compatível com Netlify.
- Validação de tiro e dano no servidor; cliente não escolhe mais diretamente o dano/alvo.
- Verificação de cadência de tiro, vida, armadura, headshot aproximado, eliminações e recompensa.
- Economia e compras validadas no servidor.
- Padrões determinísticos aproximados de spray AK-47/M4A1 e reset de spray após pausa.
- Recuo, mira dinâmica, recarga, modelos simples, flash de disparo, áudio sintético.
- HE/flash/smoke com efeitos visuais locais, chat, equipes, relógio de round e lógica básica de C4.
- Mapa desértico original com texturas procedurais, rotas e obstáculos.

## Limitações
É um protótipo jogável e não uma cópia idêntica do CS 1.6. O servidor valida os tiros usando posições recebidas dos clientes, mas ainda não simula movimento/física de forma totalmente autoritativa; os efeitos de granadas não aplicam dano/visibilidade de forma completa a todos os jogadores; não há animações de personagem/arma de alta fidelidade, sons gravados, anticheat, persistência, matchmaking, balanceamento nem todas as condições de vitória. O mapa e os assets são originais, inspirados em FPS táticos, sem arquivos proprietários da Valve. Para um jogo competitivo de produção, ainda é necessário trabalho de netcode, segurança, testes e arte 3D.
