// Configure a URL do servidor WebSocket hospedado (Render, Railway etc.).
// Exemplo: window.GAME_SERVER_URL = "wss://seu-servidor.onrender.com";
window.GAME_SERVER_URL = "";
